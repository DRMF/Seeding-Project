#!/usr/bin/env python

"""
MOSTLY WORKING:
-bessel.mpl

WORKING ON:
-modbessel.mpl

TODO LIST:
-get Besseli function to work properly
-GET THE PROGRAM TO STOP CRASHING!!! (has to do with "even" and stuff)
"""

import sys

filename = "bessel.mpl"

functions = dict((line.split(" || ")[0], line.split(" || ")[1:]) for line in
                 open("keys/functions").read().split("\n")[1:-1])

spacing = list([line, " "+line+" "] for line in
               open("keys/formatting").read().split("\n")[1:-1])

characters = list(line.split(" || ") for line in
                  open("keys/symbols").read().split("\n")[1:-1])

constraints = list(line.split(" || ") for line in
                   open("keys/constraints").read().split("\n")[1:-1])

parentheses = list(line.split(" || ") for line in
              open("keys/parens").read().split("\n")[1:-1])


def format_text(string, li):
    for key in li:
        string = string.replace(key[0], key[1])
    return string


def usage():
    print "Usage: python converter.py"
    # print "Usage: python converter.py filename"
    return sys.exit(0)


def translate_operations(exp):
    """
    Formats expression as LaTeX
        (does only operations)
    """
    for order in range(2):
        i = 0
        while i < len(exp):
            if exp[i] == "^" and order == 0:
                power = exp.pop(i+1)
                if power[-1] == ")":
                    power = ''.join(power[1:-1])
                exp[i-1] += exp.pop(i)+"{"+power+"}"
                i -= 2

            elif exp[i] == "*" and order == 1:
                if exp[i-1][0] == "\\" and exp[i+1][0] != "\\":
                    exp[i-1] = exp[i-1]+" "+exp.pop(i+1)
                else:
                    exp[i-1] += exp.pop(i+1)
                exp.pop(i)
                i -= 2

            elif exp[i] == "/" and order == 1:
                denominator = exp.pop(i+1)
                if denominator[-1] == ")":
                    denominator = ''.join(denominator[1:-1])
                exp[i-1] = "\\frac{"+exp[i-1]+"}{"+denominator+"}"
                exp.pop(i)
                i -= 2

            i += 1

    return ''.join(exp)


def convert(exp, param=dict()):
    """
    Formats based on category
    """
    exp = exp.strip()

    if param["type"] == "contfrac":
        return ""

    elif param["type"] == "series":
        pass

    print param

    parens, i = list(), 0
    exp = format_text(exp, spacing+characters+constraints).split()

    while i < len(exp):
        if exp[i] == "(":
            try:
                parens.append([i, functions[exp[i-1]]])
            except KeyError:
                parens.append([i])

        elif exp[i] == ")":
            info = parens.pop()
            l = info[0]
            piece = translate_operations(exp[l:i+1])

            if len(info) == 2:
                l -= 1
                func = info[1]
                piece = piece[1:-1].split(",")
                result = [func[-1]]
                for c in range(len(piece))[::-1]:
                    result += [piece[c], func[c]]
                piece = ''.join(result[::-1])

            exp = exp[0:l] + [piece] + exp[i+1:]
            i = l

        i += 1

    return format_text(translate_operations(exp), parentheses)


"""

def parse(li):
    """
    # Parses the input data
    """
    result, exp = list(), dict()
    li = li.split("\n")
    for line in li:
        if line != "):" and " = " in line:
            line = line.split(" = ")
            line[0] = line[0].strip()
            if line[0] in ["label", "booklabel", "parameters", "general",
                           "constraints", "begin", "even", "odd"]:
                line[1] = line[1][1:-2]

            elif line[0] in ["function", "factor", "lhs", "front"]:
                line[1] = line[1][:-1]

            elif line[0] in ["category"]:
                line[1] = line[1][1:-1]

            if line[0] in ["general", "even", "odd"]:
                line[1] = convert(line[1], exp)

            elif line[0] in ["factor", "begin", "lhs", "constraints"]:
                line[1] = convert(line[1])

            exp[line[0]] = line[1]

        elif line == "):":
            result.append(exp)
            exp = dict()

        elif "create" in line:
            exp["type"] = line[9:-2]

    return result


def generate_latex(info):
    """
    # Generates the Maple expression in its entirety
    # Does formatting based on category of Maple expression
    """

    terms = list(info)  # list of "things" provided
    print terms

    result = "\\begin{equation}\n  " + info["lhs"] + "\n  = "

    if info["type"] == "series":
        if info["category"] == "power series":
            result += info["factor"] + " \\sum_{k=0}^\\infty " + info["general"]
        elif info["category"] == "asymptotic series":
            result += info["factor"] + "\\left(" + info["general"] + \
                      "\\right), z\\rightarrow\\infty"

    elif info["type"] == "contfrac":
        # arbitrary even/odd handling
        if "even" in terms:
            info["general"] = info["even"]

        pass


        try: print info["general"]
        except Exception: print info["even"]

    else:
        print info["category"]

    # print info["general"]

    # adds metadata
    result += "\n  %  \\constraint{$"+info["constraints"] + "$}"
    result += "\n  %  \\category{"+info["category"]+"}"
    result += "\n\\end{equation}"

    return result

"""

def main():
    if len(sys.argv) != 1:
        usage()

    contents = open(filename).read()
    expressions = parse(contents)
    text = ""

    for exp in expressions:
        result = generate_latex(exp)
        text += result + "\n\n"
        print "Output for equation "+exp["booklabel"]+": \n"+result+"\n"

    with open("testing/test.tex", "w") as f:
        text = open("testing/primer").read() + text + "\\end{document}"
        f.write(text)


if __name__ == '__main__':
    main()
