#!/usr/bin/env python

import sys

filename = "test.mpl"

functions = dict((line.split(" || ")[0], line.split(" || ")[1:]) for line in
                 open("keys/functions").read().split("\n")[1:-1])

spacing = list([line, " "+line+" "] for line in
               open("keys/formatting").read().split("\n")[1:-1])

characters = list(line.split(" || ") for line in
                  open("keys/symbols").read().split("\n")[1:-1])

consts = list(line.split(" || ") for line in
              open("keys/constraints").read().split("\n")[1:-1])  # prevent "shadowing name" bug

parentheses = list(line.split(" || ") for line in
                   open("keys/parens").read().split("\n")[1:-1])


def format_text(string, li):
    for key in li:
        string = string.replace(key[0], key[1])
    return string


def usage():
    print "Usage: python converter.py"
    return sys.exit(0)


def basic_translate(exp):
    """
    Translates basic mathematical operations (does not include functions)
    Can't handle parentheses
    """
    for order in range(2):
        i = 0
        while i < len(exp):
            if exp[i] == "^" and order == 0:
                power = exp.pop(i+1)
                if power[-1] == ")":
                    power = ''.join(power[1:-1])
                exp[i-1] += exp.pop(i)+"{"+power+"}"
                i -= 2

            elif exp[i] == "*" and order == 1:
                if exp[i-1][0] == "\\" and exp[i+1][0] != "\\":  # for nicer spacing
                    exp[i-1] = exp[i-1]+" "+exp.pop(i+1)
                else:
                    exp[i-1] += exp.pop(i+1)
                exp.pop(i)
                i -= 2

            elif exp[i] == "/" and order == 1:
                denominator = exp.pop(i+1)
                if denominator[-1] == ")":
                    denominator = denominator[1:-1]
                exp[i-1] = "\\frac{"+exp[i-1]+"}{"+denominator+"}"
                exp.pop(i)
                i -= 2

            i += 1

    return ''.join(exp)


def translate(exp):
    """
    Translate a segment of Maple to LaTeX, including functions
    """
    exp = exp.strip()

    parens, i = list(), 0
    exp = format_text(exp, spacing+characters+consts).split()

    while i < len(exp):
        if exp[i] == "(":
            try:
                parens.append([i, functions[exp[i-1]]])
            except KeyError:
                parens.append([i])

        elif exp[i] == ")":
            info = parens.pop()
            l = info[0]
            piece = basic_translate(exp[l:i+1])

            if len(info) == 2:
                l -= 1
                func = info[1]
                piece = piece[1:-1].split(",")
                result = [func[-1]]
                for c in range(len(piece))[::-1]:
                    result += [piece[c], func[c]]
                piece = ''.join(result[::-1])

            exp = exp[0:l] + [piece] + exp[i+1:]
            i = l

        i += 1

    return format_text(basic_translate(exp), parentheses)


def convert(info):
    """
    Adds formatting based on the type
    """

    exp_type, category, parameters, general, lhs, factor, label, constraints = "", "", "", "", "", "", "", ""

    for param in info:
        command = param + "="

        print info[param]
        if param in ["lhs", "factor", "constraints"]:
            command += "r'"+translate(info[param])+"'"
        else:
            command += "r'"+info[param]+"'"

        exec command

    result = "\\begin{equation}\n  "+lhs+"\n  = "

    # translates the Maple information (with formatting)
    if exp_type == "series":
        general = translate(general)
        if category == "power series":
            result += factor+" \\sum_{k=0}^\\infty "+general
        elif category == "asymptotic series":
            result += factor+"\\left("+general+"\\right), z\\rightarrow\\infty"

    # adds metadata
    result += "\n  %  \\constraint{$"+constraints+"$}"
    result += "\n  %  \\category{"+category+"}"
    result += "\n\\end{equation}"

    return result


def parse(inp):
    inp = inp.split("\n")
    exp = dict()
    for line in inp:
        if "create" in line:
            exp["exp_type"] = line[9:-2]
        elif " = " in line:
            line = line.split(" = ")
            line[0] = line[0].strip()

            if line[0] in ["category"]:
                line[1] = line[1][1:-1].strip()

            elif line[0] in ["booklabel", "parameters", "general",
                             "label", "constraints"]:
                line[1] = line[1][1:-2].strip()

            elif line[0] in ["function", "lhs", "factor"]:
                line[1] = line[1][:-1].strip()

            exp[line[0]] = line[1]

    return exp


# put everything into the "generate latex" method
# keep other things as barebones as possible


def main():
    if len(sys.argv) != 1:
        usage()

    contents = open(filename).read().split("\n\n")

    for expression in contents:
        expression = parse(expression)

        print "Equation "+expression["booklabel"]+":"
        print convert(expression)+"\n\n"+"*"*64+"\n"


if __name__ == '__main__':
    main()
