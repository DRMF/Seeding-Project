class Stack:

    def __init__(self, item_list=[]):
        self.items = item_list

    def __len__(self):
        return len(self.items)

    def __str__(self):
        return str(self.items)

    def __list__(self):
        return self.items

    def has_elements(self):
        return len(self.items) > 0

    def peek(self, n=1):
        return self.items[-n]

    def pop(self):
        return self.items.pop()

    def push(self, item):
        self.items.append(item)