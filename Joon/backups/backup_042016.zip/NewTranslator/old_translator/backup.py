#!/usr/bin/env python

from modules import Stack
import sys

# constants
spacing = [
    ["(", " ( "], [")", " ) "], ["+", " + "], [",", " , "],
    ["/", " / "], ["^", " ^ "], ["*", " * "], ["exp", "e ^ "],
    [",", " , "]
]

priority = {
    "+": 1, "-": 1, "/": 2, "*": 2,
    "^": 3, "(": 0, ")": 0
}

operations = ["+", "-", "*", "/", "^"]

functions = dict((line.split(" || ")[0], line.split(" || ")[1:]) for line in
                 open("keys/functions").read().split("\n")[1:-1])

characters = list(line.split(" || ") for line in
                  open("keys/symbols").read().split("\n")[1:-1])


def usage():
    print "Usage: python filename.py *.mpl"
    sys.exit(0)


def format_text(string, li):
    for key in li:
        string = string.replace(key[0], key[1])
    return string


def initial_format(string):
    string = format_text(string, spacing).split()
    s = Stack()

    i = 0
    while i < len(string):
        if string[i] in list(functions):
            s.push((i, string[i]))
            string.pop(i)

        elif string[i] == "(":
            s.push(False)

        elif string[i] == ")":
            if not s.peek():
                s.pop()
                i += 1
                continue

            info = s.pop()
            func = functions[info[1]]
            piece = ''.join(string[info[0]+1:i]).split(",")
            result = [func[-1]]
            for c in range(len(piece))[::-1]:
                result += [piece[c], func[c]]

            piece = ''.join(result[::-1])
            string = string[0:info[0]] + [piece] + string[i+1:]
            i = info[0]

        i += 1

    return format_text(''.join(string), spacing).split()


def infix_to_postfix(exp):
    exp = format_text(exp, spacing).split()

    result = list()
    s = Stack()

    for token in exp:
        if token in list(functions):
            result.append("|")
            s.push(token)

        elif token not in list(priority):
            result.append(token)

        elif token == "(":
            s.push(token)

        elif token == ")":
            while s.peek() != "(":
                result.append(s.pop())
            s.pop() # removes the "("
            if not s.isEmpty() and s.peek() in list(functions):
                result.append(s.pop())

        else:
            while not s.isEmpty() and priority[s.peek()] >= priority[token]:
                result.append(s.pop())
            s.push(token)

    while not s.isEmpty():
        result.append(s.pop())

    return result


def convert(exp, param=""):
    """
    Converts a Maple expression to LaTeX
    """
    i = 0
    while i < len(exp):
        if exp[i] in list(functions):
            q = functions[exp[i]]
            print q

            result = list()

            while len(q) != 0:
                result.append(q.pop())
                if len(q) == 0: break
                i -= 1
                result.append(exp.pop(i))
                i -= 1
                exp.pop(i)

            exp[i] = ''.join(result[::-1])

        elif exp[i] in operations: # no combination for future efficiency
            if exp[i] == "^":
                exp[i-2] = exp[i-2]+"^{"+exp[i-1]+"}"

            elif exp[i] == "*":
                exp[i-2] = exp[i-2]+" "+exp[i-1]

            elif exp[i] == "/":
                exp[i-2] = "\\frac{"+exp[i-2]+"}{"+exp[i-1]+"}"

            elif exp[i] == "+":
                exp[i-2] = exp[i-2]+"+"+exp[i-1]

            elif exp[i] == "-":
                exp[i-2] = exp[i-2]+"-"+exp[i-1]

            exp = exp[:i-1]+exp[i+1:]
            i -= 1

        else:
            i += 1

        print exp

    return format_text(''.join(exp), characters)


def main():
    text = open(sys.argv[1]).read().split("+++++")[0][:-1]
    text = infix_to_postfix(text)
    print text
    text = convert(text)

'''
Old beginning of convert()

    if exp[0] == "[":
        exp = exp[1:-1].split(",")
        if param in ["begin", "factor"]:
            return convert(exp[0]+"/("+exp[1]+")")
        elif param in ["general"]:
            return [convert(exp[0]), convert(exp[1])]
    elif param in ["even", "odd"]:
        exp = exp.split(",")
        return [convert(exp[0]), convert(exp[1])]

    exp = infix_to_postfix(initial_format(exp))

    print exp

'''



'''
def category_format(info):
    """
    Adds formatting based on category of Maple expression
    """
    result = "\\begin{equation}\n  "+info["lhs"]+"\n  = "

    if info["category"] == 'power series':
        result += info["factor"]+" \\sum_{k=0}^\\infty "+info["general"]

    elif info["category"] == "asymptotic series":
        result += info["factor"]+"\\left("+info["general"]+"\\right), z\\rightarrow\\infty"

    elif info["category"] == "S-fraction":
        if "begin" in list(info):
            result += info["begin"]+"+\\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"
        else:
            result += info["factor"]+" \\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"

    elif info["category"] == "C-fraction":
        if "begin" in list(info):
            result += info["begin"]+"+\\CFK{m}{2}{\\infty}@{"+\
                      info["even"][0]+"}{"+info["even"][1]+"}"
        else:
            result += info["factor"]+" \\CFK{m}{2}{\\infty}@{"+\
                      info["even"][0]+"}{"+info["even"][1]+"}"

    elif info["category"] == "T-fraction":
        result += info["begin"]+"+\\CFK{m}{2}{\\infty}@{"+\
                  info["general"][0]+"}{"+info["general"][1]+"}"

    elif info["category"] == "J-fraction":
        if info["factor"][0] == "-":
            result += info["front"] + info["factor"] + "\\CFK{m}{1}{\\infty}@{" + \
                      info["general"][0] + "}{" + info["general"][1] + "}"
        else:
            result += info["front"]+"+"+info["factor"]+"\\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"

    else:
        pass

    # adds metadata
    result += "\n  %  \\constraint{$"+info["constraints"] + "$}"
    result += "\n  %  \\category{"+info["category"]+"}"
    result += "\n\\end{equation}"

    return result


def parse(li):
    """
    Parses the input data
    """
    result, exp = list(), list()
    li = li.split("\n")
    for line in li:
        if line != "):" and " = " in line:
            line = line.split(" = ")
            line[0] = line[0][2:]
            if line[0] in ["label", "booklabel", "parameters", "general",
                           "constraints", "begin", "even", "odd"]:
                line[1] = line[1][1:-2]
            elif line[0] in ["function", "factor", "lhs", "front"]:
                line[1] = line[1][:-1]
            elif line[0] in ["category"]:
                line[1] = line[1][1:-1]
            if line[0] in ["factor", "begin", "lhs", "general",
                           "constraints", "even", "odd", "front"]:
                line[1] = convert(line[1], line[0])
            exp.append(line)
        elif line == "):":
            result.append(dict((line[0], line[1]) for line in exp))
            exp = list()

    return result


def main():
    if len(sys.argv) != 2:
        usage()

    contents = open(sys.argv[1]).read()
    expressions = parse(contents)
    print expressions
    text = ""

    for exp in expressions:
        result = category_format(exp)
        text += result + "\n\n"
        print "Output for equation " + exp["booklabel"] + ": \n" + result + "\n"

    with open("testing/test.tex", "w") as f:
        text = open("testing/primer").read() + text + "\\end{document}"
        f.write(text)
'''

if __name__ == '__main__':
    main()