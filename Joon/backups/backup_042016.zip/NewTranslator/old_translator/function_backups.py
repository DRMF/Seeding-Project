#This file is a backup of old functions

def generate_info(li):
    """
    Generates the information
    """
    result = list(); stack = list()
    li = li.split("\n")
    for line in li:
        if line != "):" and " = " in line:
            line = line.split(" = ")
            line[0] = line[0][2:]
            #get rid of extra formatting stuff
            if line[0] in ["label", "booklabel", "parameters", "general", "constraints", "begin", "even", "odd"]:
                line[1] = line[1][1:-2]
            elif line[0] in ["function", "factor", "lhs"]:
                line[1] = line[1][:-1]
            elif line[0] in ["category"]:
                line[1] = line[1][1:-1]
            #converts the maple math to latex
            if line[0] in ["factor", "begin", "lhs", "general", "constraints", "even", "odd"]:
                line[1] = convert(line[1], line[0])
            stack.append(line)
        elif line == "):":
            result.append(dict((line[0], line[1]) for line in exp))
            stack = list()

    return result