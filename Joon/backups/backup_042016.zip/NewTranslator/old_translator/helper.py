#!/usr/bin/env python


def format_text(string, li):
    for key in li:
        string = string.replace(key[0], key[1])
    return string

FUNCTIONS = dict((line.split(" || ")[0], line.split(" || ")[1:]) for line in
                 open("keys/functions").read().split("\n")[1:-1])

CHARACTERS = list(line.split(" || ") for line in
                  open("keys/symbols").read().split("\n")[1:-1])

FORMATTING = [
    ["(", " ( "], [")", " ) "], ["+", " + "], [",", " , "],
    ["/", " / "], ["^", " ^ "], ["*", " * "], ["exp", "e ^ "]
]