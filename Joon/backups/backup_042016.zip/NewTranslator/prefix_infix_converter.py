#!/usr/bin/env python

from modules.Stack import Stack
import sys

# NOTE: Just fix how powers interact with negative signs. Should fix negative signs later.
# NOTE: Start work on modbessel.mpl.

# constants
priority = {
    "+": 1, "-": 1, "/": 2, "*": 2,
    "^": 3, "<": 4, ">": 4,
    "(": 0, ")": 0
}

functions = dict((line.split(" || ")[0], line.split(" || ")[1:]) for line in
                 open("keys/functions").read().split("\n")[1:-1])

spacing = list([line, " "+line+" "] for line in
               open("keys/formatting").read().split("\n")[1:-1])

characters = list(line.split(" || ") for line in
                  open("keys/symbols").read().split("\n")[1:-1])

parens = list(line.split(" || ") for line in
              open("keys/parens").read().split("\n")[1:-1])


def usage():
    print "Usage: python filename.py *.mpl"
    sys.exit(0)


def format_text(string, li):
    for key in li:
        string = string.replace(key[0], key[1])
    return string


def combine(li, op="no-parens"):
    if list(li) != li:
        return li

    if li[2] in "+-<>":
        exp = li[0]+li[2]+li[1]
    elif li[2] == "*":
        if li[0] == "-1":
            exp = "-"+li[1]
        else:
            exp = li[0]+" "+li[1]
    elif li[2] == "/":
        exp = "\\frac{"+li[0]+"}{"+li[1]+"}"
    elif li[2] == "^":
        exp = li[0]+"^{"+li[1]+"}"
    else:
        print "ERROR with list: "+str(li)
        exp = "ERROR"

    if op != "no-parens" and priority[li[2]] < priority[op]:
        exp = "("+exp+")"  # conditions to add parentheses

    return exp


def convert(exp, param=""):
    """
    Converts a Maple expression to LaTeX
    Goes from infix -> postfix (to remove all parentheses)
    Then from postfix -> infix (to add parens where needed in Mathematica)
    """
    exp = exp.strip()

    if exp[0] == "[":  # for weird form with square brackets
        exp = exp[1:-1].split(",")
        if param in ["begin", "factor"]:
            return convert(exp[0]+"/("+exp[1]+")")
        elif param in ["general"]:
            return [convert(exp[0]), convert(exp[1])]
    elif param in ["even", "odd"]:
        exp = exp.split(",")
        return [convert(exp[0]), convert(exp[1])]

    # old infix to postfix code
    exp = format_text(exp, spacing+characters).split()

    result = list()
    s = Stack()

    for token in exp:
        if token in list(functions):
            result.append("|")
            s.push(token)

        elif token == ",":
            while s.has_elements() and s.peek() in "+-*/^":
                result.append(s.pop())
            result.append(token)

        elif token not in list(priority):
            result.append(token)

        elif token == "(":
            s.push(token)

        elif token == ")":
            while s.peek() != "(":
                result.append(s.pop())
            s.pop()  # removes the "("
            if s.has_elements() and s.peek() in list(functions):
                result.append(s.pop())

        else:
            while s.has_elements() and priority[s.peek()] >= priority[token]:
                result.append(s.pop())
            s.push(token)

    while s.has_elements():
        result.append(s.pop())

    exp = result

    s = Stack()
    for token in exp:
        print "Stack: " + str(s)
        print "Token: " + str(token)
        if token in functions:
            text = list(functions[token])
            pieces = Stack(text)
            result = [pieces.pop()]

            while pieces.has_elements():
                result.append(combine(s.pop()))
                s.pop()
                result.append(pieces.pop())

            s.push(''.join(result[::-1]))

        elif token not in list(priority):
            s.push(token)

        else:
            l = [s.pop(), s.pop()][::-1]
            for i in [0, 1]:
                if i == 1 and token == "^" or token == "/":
                    l[i] = combine(l[i])
                else:
                    l[i] = combine(l[i], token)

            s.push([l[0], l[1], token])

    return format_text(combine(s.pop()), parens)


def parse(li):
    """
    Parses the input data
    """
    result, exp = list(), list()
    li = li.split("\n")
    for line in li:
        if line != "):" and " = " in line:
            line = line.split(" = ")
            line[0] = line[0][2:]
            if line[0] in ["label", "booklabel", "parameters", "general",
                           "constraints", "begin", "even", "odd"]:
                line[1] = line[1][1:-2]
            elif line[0] in ["function", "factor", "lhs", "front"]:
                line[1] = line[1][:-1]
            elif line[0] in ["category"]:
                line[1] = line[1][1:-1]
            if line[0] in ["factor", "begin", "lhs", "general",
                           "constraints", "even", "odd", "front"]:
                line[1] = convert(line[1], line[0])
            exp.append(line)
        elif line == "):":
            result.append(dict((line[0], line[1]) for line in exp))
            exp = list()
        elif "create" in line:
            exp.append(["exp-type", line[9:-2]])

    return result


def category_format(info):
    """
    Adds formatting based on category of Maple expression
    """

    result = "\\begin{equation}\n  "+info["lhs"]+"\n  = "

    if info["category"] == 'power series':
        result += info["factor"]+" \\sum_{k=0}^\\infty "+info["general"]

    elif info["category"] == "asymptotic series":
        result += info["factor"]+"\\left("+info["general"]+"\\right), z\\rightarrow\\infty"

    elif info["category"] == "S-fraction":
        if "begin" in list(info):
            result += info["begin"]+"+\\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"
        else:
            result += info["factor"]+" \\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"

    elif info["category"] == "C-fraction":
        if "begin" in list(info):
            result += info["begin"]+"+\\CFK{m}{2}{\\infty}@{"+\
                      info["even"][0]+"}{"+info["even"][1]+"}"
        else:
            result += info["factor"]+" \\CFK{m}{2}{\\infty}@{"+\
                      info["even"][0]+"}{"+info["even"][1]+"}"

    elif info["category"] == "T-fraction":
        result += info["begin"]+"+\\CFK{m}{2}{\\infty}@{"+\
                  info["general"][0]+"}{"+info["general"][1]+"}"

    elif info["category"] == "J-fraction":
        if info["factor"][0] == "-":
            result += info["front"] + info["factor"] + "\\CFK{m}{1}{\\infty}@{" + \
                      info["general"][0] + "}{" + info["general"][1] + "}"
        else:
            result += info["front"]+"+"+info["factor"]+"\\CFK{m}{1}{\\infty}@{"+\
                      info["general"][0]+"}{"+info["general"][1]+"}"

    else:
        pass

    # adds metadata
    result += "\n  %  \\constraint{$"+info["constraints"] + "$}"
    result += "\n  %  \\category{"+info["category"]+"}"
    result += "\n\\end{equation}"

    return result


def main():
    if len(sys.argv) != 2:
        usage()

    contents = open(sys.argv[1]).read()
    expressions = parse(contents)

    # print expressions
    text = ""
    for exp in expressions:
        result = category_format(exp)
        text += result + "\n\n"
        print "Output for equation " + exp["booklabel"] + ": \n" + result + "\n"

    with open("testing/test.tex", "w") as f:
        text = open("testing/primer").read() + text + "\\end{document}"
        f.write(text)


if __name__ == '__main__':
    main()
